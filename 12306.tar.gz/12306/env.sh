virtualenv .env --python=python3.7 # 第一次运行后 注释本行
source .env/bin/activate
pip install -r requirements.txt
cp env.py.example env.py